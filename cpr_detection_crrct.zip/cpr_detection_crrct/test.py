import cv2
from cvzone.HandTrackingModule import HandDetector
from cvzone.ClassificationModule import Classifier
import numpy as np
import math
import tensorflow
import time
cap=cv2.VideoCapture(0)
detector=HandDetector(maxHands=3)
classifier=Classifier("models/keras_model.h5","models/labels.txt")
offest=30

imgsize=400

counter=0
labels=["correct hand","correct handd","wrongg"]

while True:
    success , img = cap.read()
    imgFinal=img.copy()
    hands,img =detector.findHands(img)
    if hands:
        hand=hands[0]
        x,y,w,h=hand['bbox']
        imgwhite = np.ones((imgsize,imgsize,3),np.uint8)*255

        imgcrop=img[y-offest:y+ h+offest  ,x-offest:x  +w+offest]
        imgcropshape=imgcrop.shape
        imgwhite[0:imgcropshape[0],0:imgcropshape[1]]=imgcrop


        aspectRatio=h/w
        if aspectRatio>1:
            k=imgsize/h
            wcal=math.ceil(k*w)
            imagResize=cv2.resize(imgcrop,(wcal,imgsize))
            imgreizeshape = imagResize.shape
            wgap=math.ceil((imgsize-wcal)/2)
            imgwhite[:, wgap:wcal+wgap] = imagResize
            prediction , index =classifier.getPrediction(imgwhite,draw=False)
            print(prediction , index)

        else:
                k = imgsize / w
                hcal = math.ceil(k * h)
                imagResize = cv2.resize(imgcrop, ( imgsize,hcal))
                imgreizeshape = imagResize.shape
                hgap = math.ceil((imgsize - hcal) / 2)
                imgwhite[hgap:hcal + hgap, :] = imagResize
                prediction, index = classifier.getPrediction(imgwhite,draw=False)
        cv2.rectangle(imgFinal, (x - offest, y - offest-50), (x-offest+100, y-offest-50+50), (255, 0, 255), cv2.FILLED)
        cv2.putText(imgFinal,labels[index],(x,y-30),cv2.FONT_HERSHEY_TRIPLEX,1.6,(255,0,25),2)
        cv2.rectangle(imgFinal,(x-offest,y-offest),(x+w+offest,y+h+offest),(255,255,255),4)


        cv2.imshow("imagecrop",imgcrop)
        cv2.imshow("imgewhite",imgwhite)

    cv2.imshow("image",imgFinal)
    cv2.waitKey(2)

