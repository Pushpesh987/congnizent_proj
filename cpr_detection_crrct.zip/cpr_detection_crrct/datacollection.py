import cv2
from cvzone.HandTrackingModule import HandDetector
import numpy as np
import math
import time
cap=cv2.VideoCapture(0)
detector=HandDetector(maxHands=3)
offest=30

imgsize=400
folder="Data\c"
counter=0

while True:
    success , img = cap.read()
    hands , img=detector.findHands(img)
    if hands:
        hand=hands[0]
        x,y,w,h=hand['bbox']
        imgwhite = np.ones((imgsize,imgsize,3),np.uint8)*255

        imgcrop=img[y-offest:y+ h+offest  ,x-offest:x  +w+offest]
        imgcropshape=imgcrop.shape
        imgwhite[0:imgcropshape[0],0:imgcropshape[1]]=imgcrop


        aspectRatio=h/w
        if aspectRatio>1:
            k=imgsize/h
            wcal=math.ceil(k*w)
            imagResize=cv2.resize(imgcrop,(wcal,imgsize))
            imgreizeshape = imagResize.shape
            wgap=math.ceil((imgsize-wcal)/2)
            imgwhite[:, wgap:wcal+wgap] = imagResize
        else:
                k = imgsize / w
                hcal = math.ceil(k * h)
                imagResize = cv2.resize(imgcrop, ( imgsize,hcal))
                imgreizeshape = imagResize.shape
                hgap = math.ceil((imgsize - hcal) / 2)
                imgwhite[hgap:hcal + hgap, :] = imagResize


        cv2.imshow("imagecrop",imgcrop)
        cv2.imshow("imgewhite",imgwhite)

    cv2.imshow("image",img)
    key=cv2.waitKey(2)
    if key==ord("s"):
        counter+=1
        cv2.imwrite(f'{folder}/image_{time.time()}.jpg',imgwhite)
        print(counter)
